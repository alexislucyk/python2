from setuptools import setup

setup(
    name="mi_paquete",
    version="1.0",
    description="Este es mi primer paquete distribuido",
    author="Alexis Lucyk",
    author_email="alexislucyk@gmail.com",

    packages=["mi_paquete"]
)